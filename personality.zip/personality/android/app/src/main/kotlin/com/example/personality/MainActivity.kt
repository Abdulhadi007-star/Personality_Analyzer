package com.example.personality

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
